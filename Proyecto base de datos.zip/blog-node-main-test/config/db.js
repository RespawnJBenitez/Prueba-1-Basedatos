module.exports = {
	host: 'localhost',
	user: 'root',
	database: 'prestamos_bcs',
	password: '',
	port: 3306,
}
