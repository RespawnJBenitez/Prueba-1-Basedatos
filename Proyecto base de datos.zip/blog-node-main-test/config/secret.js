module.exports = {
    SECRET: 'CLAVE_SECRETA_SUPERSEGURA'
}