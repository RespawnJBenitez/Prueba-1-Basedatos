const express = require('express');
const router = express.Router();

const postService = require('../services/abonosService')
const {verifyToken} = require('../middleware/authJwt');

router.get("/", verifyToken, async (req, res) => {
		[results] = await postService.getAll();
	res.json({ code: 200, message: '', data: results});
})

// Traerme un id especifico
router.get("/:id",verifyToken, async(req, res) => {
	const id = req.params.id;
	[results] = await postService.get(id);
	res.json({code: 200, message: '', data: results});
})

// Agrega-Insertar abono
router.post('/',verifyToken, async(req, res) => {
	const abono = req.body.abono;
	const prestamo_id = req.body.prestamo_id;
	
	//const {cantidad,plazos,persona_curp, autorizado} = req.body;
	[results ] = await postService.save(abono,prestamo_id);
	if(results.affectedRows === 1) 
		res.json({code: 201, message: 'Datos guardados correctamente'});
	else
		res.json({code: 400, message: 'Ocurrió un error al intentar guardar los datos'})
});

router.delete('/:id',verifyToken, async(req, res) => {
	const id = req.params.id;
	[results] = await postService.remove(id);
	if(results.affectedRows === 1) 
		res.json({code: 200, message: 'Datos eliminados correctamente'});
	else
		res.json({code: 200, message: 'Recurso no encontrado'})
});

module.exports = router;
