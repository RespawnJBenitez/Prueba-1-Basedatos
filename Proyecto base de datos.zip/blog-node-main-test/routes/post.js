const express = require('express');
const router = express.Router();

const postService = require('../services/postService')
const {verifyToken} = require('../middleware/authJwt');
const checkCurp = require('../middleware/checkCurp');

router.get("/", verifyToken, async (req, res) => {
		[results] = await postService.getAll();
	res.json({ code: 200, message: '', data: results});
})

// Personas obtener datos
router.get("/curp",  async (req, res) => {
	[results] = await postService.getAllPersonas();
res.json({ code: 200, message: '', data: results});
})

router.get("/curp/:curp", verifyToken, async(req, res) => {
	const curp = req.params.curp;
	[results] = await postService.getCurp(curp);
	res.json({code: 200, message: '', data: results});
})

// Traerme un id especifico
router.get("/:id", verifyToken, async(req, res) => {
	const id = req.params.id;
	[results] = await postService.get(id);
	res.json({code: 200, message: '', data: results});
})

// Agrega-Insertar prestamos cantidad,plazos,persona_curp, autorizado
router.post('/',verifyToken, checkCurp, async(req, res) => {
	const cantidad = req.body.cantidad;
	const plazos = req.body.plazos;
	const persona_curp = req.body.persona_curp;
	const autorizado = req.body.autorizado;
	//const {cantidad,plazos,persona_curp, autorizado} = req.body;
	[results ] = await postService.save(cantidad,plazos,persona_curp, autorizado);
	if(results.affectedRows === 1) 
		res.json({code: 201, message: 'Datos guardados correctamente'});
	else
		res.json({code: 400, message: 'Ocurrió un error al intentar guardar los datos'})
});

router.delete('/:id', verifyToken, async(req, res) => {
	const id = req.params.id;
	[results] = await postService.remove(id);
	if(results.affectedRows === 1) 
		res.json({code: 200, message: 'Datos eliminados correctamente'});
	else
		res.json({code: 200, message: 'Recurso no encontrado'})
});

module.exports = router;
