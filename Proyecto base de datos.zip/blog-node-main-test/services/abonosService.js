const db = require('../database/db');

const TABLE = 'abonos';

const getAll = async ()  =>  {
	const conn = await db.getConnection();
	const query = `SELECT * FROM ${TABLE}`;

	return conn.execute(query);
}

const get = async (id) => {
	const conn = await db.getConnection();
	const query = `SELECT * FROM ${TABLE} WHERE id = ?`;

	return conn.execute(query, [id]);
}
// Insertar abono
const save = async (abono,prestamo_id) => {
	const conn = await db.getConnection();
	const query =  `INSERT INTO ${TABLE}(abono,prestamo_id) VALUE(?, ?)`;
	return conn.execute(query, [abono,prestamo_id]);
}

const remove = async (id) => {
	const conn = await db.getConnection();
	const query = `DELETE FROM ${TABLE} WHERE id = ?`;
	return conn.execute(query, [id]);
}

exports.getAll = getAll;
exports.get = get;
exports.save = save;
exports.remove = remove;