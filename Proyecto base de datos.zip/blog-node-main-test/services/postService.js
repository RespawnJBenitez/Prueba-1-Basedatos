const db = require('../database/db');
const TABLE = 'prestamos';
const TABLE2 = 'personas';

//Atraer la tablas de las personas
const getAllPersonas = async ()  =>  {
	const conn = await db.getConnection();
	const query = `SELECT * FROM ${TABLE2}`;

	return conn.execute(query);
}

//Obtener el curp de las personas para mostrar tabla
const getCurp = async (curp) => {
	const conn = await db.getConnection();
	const query = `SELECT * FROM ${TABLE2} WHERE curp = ?`;

	return conn.execute(query, [curp]);
}

const getAll = async ()  =>  {
	const conn = await db.getConnection();
	const query = `SELECT * FROM ${TABLE}`;

	return conn.execute(query);
}

//Traer prestamos 
const get = async (id) => {
	const conn = await db.getConnection();
	const query = `SELECT * FROM ${TABLE} WHERE id = ?`;

	return conn.execute(query, [id]);
}
// Insertar prestamos
const save = async (cantidad,plazos,persona_curp, autorizado) => {
	const conn = await db.getConnection();
	const query =  `INSERT INTO ${TABLE}(cantidad,plazos,persona_curp, autorizado) VALUE(?, ?,?,?)`;
	return conn.execute(query, [cantidad,plazos,persona_curp, autorizado]);
}

const remove = async (id) => {
	const conn = await db.getConnection();
	const query = `DELETE FROM ${TABLE} WHERE id = ?`;
	return conn.execute(query, [id]);
}

exports.getAll = getAll;
exports.get = get;
exports.save = save;
exports.remove = remove;
exports.getAllPersonas = getAllPersonas;
exports.getCurp = getCurp;

// Comprobar si existe el curp
const existCurp = async(persona_curp) => {
	const conn = await db.getConnection();
	const query = `SELECT COUNT(*) as total FROM ${TABLE} WHERE persona_curp = ?`;
	const [[result]] = await conn.execute(query, [persona_curp]);
	if(result.total == 0)
		throw new Error('No se encuentra la persona que se quiere realizar el prestamo');
}


exports.existCurp = existCurp;