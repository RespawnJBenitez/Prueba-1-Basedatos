const {existCurp} = require('../services/postService');

module.exports = async (req, res, next) =>{
    try {
        await existCurp(req.body.persona_curp);
        next();
    } catch(e) {
        res.status(400).send(e.message)
    }
}